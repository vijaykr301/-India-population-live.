# India + World Live Population Board

Vertical 9:16 HTML/CSS/JavaScript overlay for a YouTube Live stream.

## Publish with GitHub Pages
1. Create a new GitHub repository.
2. Upload `index.html` and `README.md`.
3. Open **Settings → Pages**.
4. Under **Build and deployment**, choose **Deploy from a branch**.
5. Select branch `main` and folder `/(root)`, then save.
6. Open the URL shown in Pages after deployment completes.

## Use for YouTube Live
Add the published URL as a Browser Source in OBS Studio. Set the canvas/output to 1080×1920 for a vertical stream.

The counters use illustrative starting values and approximate annual rates in the JavaScript. They do not connect to a live data API.
